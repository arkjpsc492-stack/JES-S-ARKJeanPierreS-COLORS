import MuseScore 3.0

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Window 2.2


MuseScore {

    menuPath: "Plugins.ARKJeanPierreS"

    description: "ARK JeanPierreS COLORS"

    version: "4.0"



    Settings {

        id:configuracion

        category:"ARKJeanPierreS_COLORS"

    }



    property var notas: [
        "DO",
        "DO#/REb",
        "RE",
        "RE#/MIb",
        "MI",
        "FA",
        "FA#/SOLb",
        "SOL",
        "SOL#/LAb",
        "LA",
        "LA#/SIb",
        "SI"
    ]



    property var nombresARK: [
        "DO",
        "DU",
        "RE",
        "RU",
        "MI",
        "FA",
        "FU",
        "SOL",
        "SEL",
        "LA",
        "LU",
        "SI"
    ]



    property var coloresNotas: [

        "#00BFFF",
        "#00FFF0",
        "#FF0000",
        "#8000FF",
        "#FFFF00",
        "#FF6600",
        "#004CFF",
        "#00FF00",
        "#990066",
        "#FF66CC",
        "#800080",
        "#FFFFFF"

    ]



    property int notaActual:0

    property bool mostrarPaleta:false

    property bool colorearAcordesActivado:true




    function cargarConfiguracion(){


        for(var i=0;i<12;i++){


            coloresNotas[i]=configuracion.value(

                "nota_"+i,

                coloresNotas[i]

            )


        }



        colorearAcordesActivado=configuracion.value(

            "acordes",

            true

        )



        coloresNotas=coloresNotas.slice()


    }




    function guardarConfiguracion(){


        for(var i=0;i<12;i++){


            configuracion.setValue(

                "nota_"+i,

                coloresNotas[i]

            )


        }



        configuracion.setValue(

            "acordes",

            colorearAcordesActivado

        )


    }




    Component.onCompleted:{


        cargarConfiguracion()


    }




    function restaurarTodaLaPartitura(){


        if(!curScore)

            return



        cmd("select-all")

        curScore.startCmd()



        for(var i=0;
            i<curScore.selection.elements.length;
            i++){



            var elemento =
            curScore.selection.elements[i]



            if(elemento.pitch){


                elemento.color="#000000"



                if(elemento.accidental)

                    elemento.accidental.color="#000000"



                if(elemento.dots){


                    for(var d=0;
                        d<elemento.dots.length;
                        d++){


                        if(elemento.dots[d])

                            elemento.dots[d].color="#000000"


                    }


                }


            }



            if(elemento.type===Element.HARMONY){


                elemento.color="#000000"


            }


        }



        curScore.endCmd()

        cmd("escape")


    }
    property var paleta: [

        "#00E5FF",
        "#00CCFF",
        "#0099FF",

        "#00FFF0",
        "#00FFD0",
        "#00FF99",

        "#CCFF00",
        "#99FF00",
        "#66FF00",

        "#FFFF00",
        "#FFFF33",
        "#EFFF00",

        "#FFD700",
        "#FFC000",
        "#E6A800",

        "#FF9900",
        "#FF6600",
        "#FF3300",

        "#FF8066",
        "#FF604D",
        "#FF3333",

        "#FF0000",
        "#CC0000",
        "#990000",

        "#990033",
        "#800040",
        "#660033",

        "#CC00FF",
        "#9900FF",
        "#6600CC",

        "#5500FF",
        "#4400CC",
        "#330099",

        "#00A2FF",
        "#006CFF",
        "#0033FF",
        "#FF0000","#FF3333","#FF6666","#FF9999","#FFCCCC",
        "#CC0000","#990000","#660000","#FF0033","#FF0066",

        "#FF6600","#FF8000","#FF9900","#FFB300","#FFCC00",
        "#CC6600","#FF4500","#FF7F00","#FFA500","#FF5500",

        "#FFFF00","#FFFF33","#FFFF66","#FFFF99","#FFFFCC",
        "#FFD700","#E6C200","#CC9900","#FFF200","#F4FF00",

        "#00FF00","#33FF00","#66FF00","#99FF00","#CCFF00",
        "#00CC00","#009900","#006600","#00FF66","#00FF99",

        "#00FFFF","#00FFCC","#00FFAA","#00CCAA","#009999",
        "#00CCCC","#33FFFF","#66FFFF","#00AAAA","#008888",

        "#00E5FF","#33CCFF","#66CCFF","#99DDFF","#CCEEFF",
        "#0099FF","#00BFFF","#66D9FF","#80FFFF","#40E0D0",

        "#0000FF","#0033FF","#0066FF","#0099FF","#3366FF",
        "#0000CC","#000099","#003366","#006699","#004CFF",

        "#FF00FF","#EE00FF","#CC00FF","#AA00FF","#8800FF",
        "#6600FF","#5500AA","#4B0082","#800080","#9933FF",

        "#FF0099","#FF3399","#FF6699","#FF99CC","#FFCCFF",
        "#FF1493","#FF69B4","#FFB6C1","#FF77AA","#FF55BB",

        "#000000",
        "#111111",
        "#222222",
        "#333333",
        "#444444",
        "#555555",
        "#666666",
        "#777777",
        "#888888",
        "#999999",
        "#AAAAAA",
        "#BBBBBB",
        "#CCCCCC",
        "#DDDDDD",
        "#EEEEEE",
        "#FFFFFF",

        "#3B1F00",
        "#5C2E00",
        "#7A3F00",
        "#8B4513",
        "#A0522D",
        "#C08040",
        "#D2B48C",
        "#E6C8A0"

    ]



    onRun: ventana.show()



    Window {

        id:ventana

        width:1100

        height:850

        title:"🚢 ARK JeanPierreS COLORS"



        Rectangle {

            anchors.fill:parent

            color:"#111111"



            Text {

                anchors.right:parent.right

                anchors.top:parent.top

                anchors.margins:15


                text:
                "✝ Jesús te ama\n"+
                "Juan 3:16\n"+
                "Juan 19:30\n"+
                "Juan 14:8-9\n"+
                "Mateo 28:19-20\n"+
                "Génesis 9:12-13"



                color:"white"

                font.pixelSize:12

                horizontalAlignment:Text.AlignRight

            }



            Column {

                anchors.centerIn:parent

                spacing:15



                Text {

                    text:"🚢 ARK JeanPierreS COLORS"

                    color:"#FFD700"

                    font.pixelSize:34

                    font.bold:true

                }



                Text {

                    text:"Sistema cromático artístico"

                    color:"white"

                    font.pixelSize:20

                }
                Grid {

                    columns:3

                    spacing:10


                    Repeater {

                        model:12


                        Row {

                            spacing:8


                            Button {

                                width:200

                                height:55


                                text:notas[index]


                                background:Rectangle {

                                    color:coloresNotas[index]

                                    radius:10

                                }



                                onClicked:{

                                    notaActual=index

                                    mostrarPaleta=true

                                }


                            }



                            Text {

                                text:nombresARK[index]

                                color:"white"

                                font.bold:true

                                font.pixelSize:24

                            }


                        }


                    }


                }



                Rectangle {

                    width:950

                    height:220

                    color:"#202020"

                    radius:15

                    visible:mostrarPaleta



                    Grid {

                        anchors.centerIn:parent

                        columns:16

                        spacing:5



                        Repeater {

                            model:paleta.length



                            Rectangle {

                                width:35

                                height:25

                                radius:4

                                color:paleta[index]

                                border.color:"#FFFFFF"

                                border.width:1



                                MouseArea {

                                    anchors.fill:parent



                                    onClicked:{


                                        coloresNotas[notaActual]=paleta[index]


                                        coloresNotas=
                                        coloresNotas.slice()



                                        guardarConfiguracion()



                                        mostrarPaleta=false


                                    }


                                }


                            }


                        }


                    }


                }





                Button {

                    width:350

                    height:55


                    text:"🌈 COLOREAR PARTITURA"



                    background:Rectangle {

                        color:"#FFD700"

                        radius:15

                    }



                    onClicked:{


                        if(!curScore)

                            return



                        cmd("select-all")

                        curScore.startCmd()



                        for(var i=0;
                            i<curScore.selection.elements.length;
                            i++){


                            var e =
                            curScore.selection.elements[i]



                            if(e.pitch){



                                var c =
                                coloresNotas[e.pitch % 12]



                                e.color=c



                                if(e.accidental)

                                    e.accidental.color=c



                                if(e.dots){


                                    for(var d=0;
                                        d<e.dots.length;
                                        d++){


                                        if(e.dots[d])

                                            e.dots[d].color=c


                                    }


                                }


                            }


                        }



                        curScore.endCmd()

                        cmd("escape")


                    }


                }





                Button {

                    width:350

                    height:55


                    text:"⬛ RESTAURAR TODA LA PARTITURA"



                    onClicked:{


                        restaurarTodaLaPartitura()


                    }


                }





                Button {

                    width:350

                    height:55


                    text:"🎸 COLOREAR ACORDES"



                    onClicked:{


                        if(!curScore)

                            return



                        cmd("select-all")

                        curScore.startCmd()



                        for(var i=0;
                            i<curScore.selection.elements.length;
                            i++){


                            var e =
                            curScore.selection.elements[i]



                            if(e.type===Element.HARMONY){



                                var t=e.text



                                if(t){


                                    var l=t.charAt(0).toUpperCase()



                                    if(l==="C")

                                        e.color=coloresNotas[0]

                                    if(l==="D")

                                        e.color=coloresNotas[2]

                                    if(l==="E")

                                        e.color=coloresNotas[4]

                                    if(l==="F")

                                        e.color=coloresNotas[5]

                                    if(l==="G")

                                        e.color=coloresNotas[7]

                                    if(l==="A")

                                        e.color=coloresNotas[9]

                                    if(l==="B")

                                        e.color=coloresNotas[11]


                                }


                            }


                        }



                        curScore.endCmd()

                        cmd("escape")


                    }


                }





                Button {

                    width:350

                    height:55


                    text:"⬛ QUITAR COLOR DE ACORDES"



                    onClicked:{


                        if(!curScore)

                            return



                        cmd("select-all")

                        curScore.startCmd()



                        for(var i=0;
                            i<curScore.selection.elements.length;
                            i++){


                            var e =
                            curScore.selection.elements[i]



                            if(e.type===Element.HARMONY)

                                e.color="#000000"


                        }



                        curScore.endCmd()

                        cmd("escape")


                    }


                }





                Button {

                    width:350

                    height:55


                    text:"💾 GUARDAR COLORES"



                    onClicked:{


                        guardarConfiguracion()


                    }


                }




            }


        }


    }


}
